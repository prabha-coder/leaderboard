<?php
$t = new Schema('elfinder_file');
$t->add('parent_id','int',7);
$t->add('name','varchar',256);
$t->add('content','longblob');
$t->add('size','int',10);
$t->add('mtime','int',10);
$t->add('mime','varchar',256,'unknown');
$t->add('read','enum','\'1\', \'0\'',1);
$t->add('write','enum','\'1\', \'0\'',1);
$t->add('locked','enum','\'1\', \'0\'',0);
$t->add('hidden','enum','\'1\', \'0\'',0);
$t->add('width','int',5);
$t->add('height','int',5);
$t->add_extras(',
  UNIQUE KEY  `parent_name` (`parent_id`, `name`),
  KEY         `parent_id`   (`parent_id`)');
$t->set_engine('MyISAM');
$t->add_primary_data('(`id`, `parent_id`, `name`,     `content`, `size`, `mtime`, `mime`,      `read`, `write`, `locked`, `hidden`, `width`, `height`) VALUES 
(\'1\',  \'0\',         \'Database\', \'\',        \'0\',    \'0\',     \'directory\', \'1\',    \'1\',     \'0\',      \'0\',      \'0\',     \'0\')');
$t->save();

add_option('media_database','no');
add_option('media_theme','win10');

