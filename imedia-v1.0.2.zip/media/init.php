<?php

// Copyright (c) <Y> Sadia Sharmin

$action = route(2);

$ui->assign('_application_menu', 'tickets');
$ui->assign('_title', 'Media Library'.' - '. $config['CompanyName']);
$ui->assign('_st', 'Media Library');
$user = User::_info();
$ui->assign('user', $user);

switch ($action) {

    case 'app':

        if($_app_stage == 'Demo'){

            $ui->assign('info','<div class="col-md-12"><div class="alert alert-danger fade in">
							
								<button class="close" data-dismiss="alert">
									×
								</button>
								File Creating & Uploading is disabled in the Demo Mode.
							</div></div>');

        }
        else{
            $ui->assign('info','');
        }

        $lan_extra = '';

        $lan_xjq = '';

        $media_theme = $config['media_theme'];

        if($media_theme == 'default'){

            $m_css = '<link rel="stylesheet" type="text/css" media="screen" href="'.APP_URL.'/application/plugins/media/themes/moono/css/theme.css">';
        }
        elseif ($media_theme == 'win10'){
            $m_css = '<link rel="stylesheet" type="text/css" media="screen" href="'.APP_URL.'/application/plugins/media/themes/w/css/theme.css">';
        }
        else{
            $m_css = '';
        }

        $language = $config['language'];

        $lan_el = Ib_I18n::get_ef($language);

        if($language != 'en-us'){
            // <script src="js/i18n/elfinder.ru.js"></script>
            $lan_extra = '<script src="'.APP_URL.'/application/plugins/media/js/i18n/elfinder.'.$lan_el.'.js"></script>';
            $lan_xjq = ', lang: \''.$lan_el.'\' ';
        }

        $ui->assign('xheader','<link rel="stylesheet" type="text/css" href="//ajax.googleapis.com/ajax/libs/jqueryui/1.11.4/themes/smoothness/jquery-ui.css">
<link rel="stylesheet" type="text/css" href="'.APP_URL.'/application/plugins/media/css/elfinder.min.css">
<link rel="stylesheet" type="text/css" href="'.APP_URL.'/application/plugins/media/css/theme.css">
'.$m_css.'
');

        $ui->assign('xfooter','<script src="'.APP_URL.'/application/plugins/media/js/elfinder.min.js"></script>
'.$lan_extra.'
');


        $ui->assign('xjq','$(\'#ib_media_render\').elfinder({
					url : \''.U.'media/init/ibilling_adapter/\' ,
					height: 700,
                uiOptions: {
                    toolbar : [
                        // toolbar configuration
                        [\'open\'],
                        [\'back\', \'forward\'],
                        [\'reload\'],
                        [\'home\', \'up\'],
                        [\'mkdir\', \'mkfile\', \'upload\'],
                        [\'info\'],
                        [\'quicklook\'],
                        [\'copy\', \'cut\', \'paste\'],
                        [\'rm\'],
                        [\'duplicate\', \'rename\', \'edit\'],
                        [\'extract\', \'archive\'],
                        [\'search\'],
                        [\'view\']
                    ]
                }
					 '.$lan_xjq.' 
				});');


        $ui->assign('_include','render');
        $ui->display('wrapper.tpl');


        break;


    case 'ibilling_adapter':

        require 'application/plugins/media/adapter/autoload.php';

        function media_access($attr, $path, $data, $volume) {
            return strpos(basename($path), '.') === 0       // if file/folder begins with '.' (dot)
                ? !($attr == 'read' || $attr == 'write')    // set read+write to false, other (locked+hidden) set to true
                :  null;                                    // else elFinder decide it itself
        }


        if($_app_stage == 'Demo'){

            $local_file = array(
                'driver'        => 'LocalFileSystem',           // driver for accessing file system (REQUIRED)
                'path'          => 'application/plugins/media/storage/',                 // path to files (REQUIRED)
                'URL'           => APP_URL.'/application/plugins/media/storage/', // URL to files (REQUIRED)
                // 'uploadDeny'    => array('all'),                // All Mimetypes not allowed to upload
                'uploadDeny'    => array(),                // All Mimetypes not allowed to upload
                //  'uploadAllow'   => array('image', 'text/plain'), // Mimetype `image` and `text/plain` allowed to upload
                'uploadAllow'   => array(), // Mimetype `image` and `text/plain` allowed to upload
                'uploadOrder'   => array('allow', 'deny'),      // allowed Mimetype `image` and `text/plain` only
                'disabled' => array('rename','delete'),
                'accessControl' => 'media_access'                     // disable and hide dot starting files (OPTIONAL)
            );

        }
        else{

            $local_file = array(
                'driver'        => 'LocalFileSystem',           // driver for accessing file system (REQUIRED)
                'path'          => 'application/plugins/media/storage/',                 // path to files (REQUIRED)
                'URL'           => APP_URL.'/application/plugins/media/storage/', // URL to files (REQUIRED)
                // 'uploadDeny'    => array('all'),                // All Mimetypes not allowed to upload
                'uploadDeny'    => array(),                // All Mimetypes not allowed to upload
                //  'uploadAllow'   => array('image', 'text/plain'), // Mimetype `image` and `text/plain` allowed to upload
                'uploadAllow'   => array('image','application','text'), // Mimetype `image` and `text/plain` allowed to upload
                'uploadOrder'   => array('deny', 'allow'),      // allowed Mimetype `image` and `text/plain` only
                'accessControl' => 'media_access'                     // disable and hide dot starting files (OPTIONAL)
            );

        }





        if($config['media_database'] == 'yes'){
            $opts = array(
                // 'debug' => true,
                'roots' => array(
                    $local_file,
                    array(
                        'driver' => 'MySQL',
                        'host'   => $db_host,
                        'user'   => $db_user,
                        'pass'   => $db_password,
                        'db'     => $db_name,
                        'path'   => 1,
                    )
                )
            );
        }
        else{
            $opts = array(
                // 'debug' => true,
                'roots' => array(
                    $local_file
                )
            );
        }

// run elFinder
        $connector = new elFinderConnector(new elFinder($opts));
        $connector->run();



        break;

    case 'settings':


        $ui->assign('xjq','var _url = $("#_url").val();
  $("#li_media").removeClass("active");
    $(\'#media_database\').change(function() {

        $(\'#ui_settings\').block({ message: null });


      if($(this).prop(\'checked\')){

          $.post( _url+\'settings/update_option/\', { opt: "media_database", val: "yes" })
              .done(function( data ) {
                $(\'#ui_settings\').unblock();
                  location.reload();
              });

      }
        else{
          $.post( _url+\'settings/update_option/\', { opt: "media_database", val: "no" })
              .done(function( data ) {
                  $(\'#ui_settings\').unblock();
                  location.reload();
              });
      }
    });
    
        $(\'#media_theme\').change(function() {

        $(\'#ui_settings\').block({ message: null });

$.post( _url+\'settings/update_option/\', { opt: "media_theme", val: $(this).val() })
              .done(function( data ) {
                $(\'#ui_settings\').unblock();
                  location.reload();
              });
      
    });
    
    ');

        //override routes

        $ui->assign('_application_menu','settings');
        $ui->assign('_include','settings');
        $ui->display('wrapper.tpl');




        break;







    default:
        echo 'action not defined';
}