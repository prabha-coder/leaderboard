<?php
$plugin = array();
$plugin['name'] = 'Media Library';
$plugin['author'] = 'Sadia Sharmin';
$plugin['version'] = '1.0.2';
$plugin['description'] = 'Media Library Plugin';
$plugin['url'] = 'http://www.ibilling.io/plugin-development/';