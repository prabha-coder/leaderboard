<?php
$t = new Schema('elfinder_file');
$t->drop();

delete_option('media_database');
delete_option('media_theme');