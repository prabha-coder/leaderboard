<?php
add_menu_admin('Media',U.'media/init/app/','media','icon-drive');
add_sub_menu_admin('settings','Media Settings',U.'media/init/settings/');

