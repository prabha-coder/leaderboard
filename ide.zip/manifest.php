<?php
$plugin = array();
$plugin['name'] = 'IDE';
$plugin['author'] = 'Your Name';
$plugin['version'] = '1.0.2';
$plugin['description'] = 'iBilling Developer Tools';
$plugin['url'] = 'http://www.ibilling.io/plugin-development/';