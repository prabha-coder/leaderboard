<?php
add_menu_admin('IDE',U.'ide/init/render/','ide','icon-drive');

