<?php

_auth();

$ui->assign('_application_menu', 'ide');
$ui->assign('_title', 'Editor'.' - '. $config['CompanyName']);
$ui->assign('_st', 'iBilling IDE');
$action = $routes['2'];
$user = User::_info();
$ui->assign('user', $user);


$panel_body_1 = '<div id="ib_tree"></div>';
$panel_body_2 = '';

$menu_items = null;

$view = new View();

$menu = array(
    'title'=>'<a href="'.U.'ide/init/render/"><img src="'.APP_URL.'/application/plugins/ide/views/imgs/ide_logo.png"> </a>',
    'panel_body_1'=>$panel_body_1,  # Optional
    'items'=> $menu_items,
    'panel_body_2'=>$panel_body_2,  # Optional
    'panel_body_3'=>''  # Optional
);



switch ($action) {
    case 'render':

        $ui->assign('menu',$view->buildMenuListGroup($menu)->getHtml());
        $ui->assign('xheader',Asset::css(array('modal','dropzone/dropzone')).$PluginManager->css(array('ide/views/css/style')));
        $ui->assign('xfooter',Asset::js(array('modal','dropzone/dropzone')).$PluginManager->js(array('ide/lib/ace/ace','ide/lib/ace/ext-modelist','ide/views/js/jqueryFileTree','ide/views/js/app')));
        $ui->assign('_include','box');
        $ui->display('wrapper.tpl');

        break;

    case 'app':


        $ui->assign('xheader',Asset::css(array('modal','dropzone/dropzone')).$PluginManager->css(array('ide/views/css/paper.min','ide/lib/angular/filemanager.min')));
        $ui->assign('xfooter',Asset::js(array('modal','dropzone/dropzone')).$PluginManager->js(array('ide/lib/angular/angular.min','ide/lib/angular/angular-translate.min','ide/lib/angular/filemanager.min','ide/views/js/jqueryFileTree','ide/views/js/app')));
        $ui->assign('_include','app');
        $ui->display('pl.tpl');


        break;



    default:
        echo 'action not defined';
}
